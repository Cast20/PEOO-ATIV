
package questão.pkg2;


public class ContaDeBanco {
    private String nome;
    private double saldo;
    
    public ContaDeBanco(){
        
    }
    public ContaDeBanco(String nome){
        this.nome = nome;
        this.saldo = 0;
    }
    
    public void ConsultarNome(){
        System.out.println("O nome atual é "+ this.nome); 
    }
    public void ConsultarSaldo (){
        System.out.println("O saldo atual é "+ this.saldo); 
    }
    public void Sacar(double d){
        this.saldo -= d;
        System.out.println("Saldo atual: "+ this.saldo);
    }
    public void Depositar(double d){
        this.saldo += d;
        System.out.println("Saldo atual: "+ this.saldo);
    }
    public void AlterarNome(String n){
        this.nome = n;
        System.out.println("O nome foi alterado para "+ this.nome);
    }
}
