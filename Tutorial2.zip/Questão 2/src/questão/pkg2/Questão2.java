
package questão.pkg2;

import java.util.Scanner;


public class Questão2 {

    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ContaDeBanco cl = new ContaDeBanco ();
        
        System.out.println("Digite seu nome...");
        String n = sc.nextLine();
        
        cl.AlterarNome(n);
        
        for (int i = 0; i < 1;) {
            System.out.println("1-Sacar"+ "2-Depositar"+"3-Consultar saldo"+"4-|Sair");
            int num = sc.nextInt();
            switch (num){
                case 1:
                    System.out.println("Digite um valor para sacar...");
                    double v = sc.nextDouble();
                    cl.Sacar(v);
                    break;
                case 2:
                    System.out.println("Digite um valor para depositar...");
                    v = sc.nextDouble();
                    cl.Depositar(v);
                    break;
                case 3:
                    cl.ConsultarSaldo();
                    break;
                case 4:
                    i++;
                    break;
                
            }
        }
    }
    
}
